let originalArray = ["1", "2", "3", "4", "5", "6", "7", "8", "9"];
let displayArray = [];

function initialBoard() {
    displayArray = [...originalArray];
    renderBoard();
}

function setRandomOrder() {
    displayArray = [...originalArray].sort(() => Math.random() - 0.5);
    return displayArray;
}

function getItem() {
    return displayArray.pop();
}

function setDisplayBoard(event) {
    const index = event.target.dataset.index;
    const value = getItem();
    if (value !== undefined) {
        displayArray[index] = value;
        renderBoard();
    }
}

function renderBoard() {
    const matrixContainer = document.getElementById("matrix-container");
    matrixContainer.innerHTML = "";

    for (let i = 0; i < 3; i++) {
        for (let j = 0; j < 3; j++) {
            const cell = document.createElement("div");
            cell.className = "cell";
            cell.dataset.index = i * 3 + j;
            cell.textContent = displayArray[i * 3 + j];
            cell.addEventListener("click", setDisplayBoard);
            matrixContainer.appendChild(cell);
        }
    }

    const clearButton = document.getElementById("clear-button");
    clearButton.addEventListener("click", initialBoard);
}

initialBoard();
